﻿using System.Windows;
using Microsoft.EntityFrameworkCore;
using Pilnik.Models;
using System.Linq;



namespace Pilnik.Views
{
    public partial class Viewing_the_list_of_ordersWindow : Window
    {
        private readonly PilnikContext _context;

        public Viewing_the_list_of_ordersWindow()
        {
            InitializeComponent();

            _context = new PilnikContext();
            LoadOrdersAsync();
            backButton.Click += (sender, e) =>
            {
                AdminWindow mainWindow = new AdminWindow();
                mainWindow.Show();
                this.Close();
            };
        }

        public List<Order> Orders { get; set; } = new List<Order>();

        private async void LoadOrdersAsync()
        {
            Orders = await _context.Orders
                .Include(o => o.User)
                .Include(o => o.OrderProducts)
                    .ThenInclude(op => op.Product)
                .ToListAsync();

            OrdersGrid.ItemsSource = Orders;
        }

        private void DeleteOrderButton_Click(object sender, RoutedEventArgs e)
        {

        }

        private void AddOrderButton_Click(object sender, RoutedEventArgs e)
        {

        }

    }
}
