﻿using Pilnik.Models;
using System;
using System.Linq;
using System.Threading.Tasks;
using System.Windows;
using Microsoft.EntityFrameworkCore;

namespace Pilnik.Views
{
    
    public partial class Shift_managementWindow : Window
    {
        private readonly PilnikContext _context;
        private Completing_shiftsWindow _completing_shiftsWindow;

        public Shift_managementWindow()
        {
            InitializeComponent();
            _context = new PilnikContext();
            LoadShiftsAsync();

            backButton.Click += (sender, e) =>
            {
                new AdminWindow().Show();
                Close();
            };

            addButton.Click += NewShiftButton_Click;

        }

        private async Task LoadShiftsAsync()
        {
            try
            {
                var shifts = await _context.Shifts
                    .Include(s => s.ShiftUsers)
                       .ThenInclude(su => su.User)
                    .OrderByDescending(s => s.StartShift)
                    .ToListAsync();

                ShiftsGrid.ItemsSource = shifts;


            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message);
            }

        }

        private async void NewShiftButton_Click(object sender, RoutedEventArgs e)
        {
            if (_completing_shiftsWindow == null || !_completing_shiftsWindow.IsVisible)
            {
                _completing_shiftsWindow = new Completing_shiftsWindow();
                _completing_shiftsWindow.Closed += async (a, args) =>
                {
                    _completing_shiftsWindow = null;
                    await LoadShiftsAsync();
                };
                _completing_shiftsWindow.Show();
            }
            else
            {
                _completing_shiftsWindow.Activate();

            }
        }
    }
}

