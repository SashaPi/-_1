﻿using Microsoft.EntityFrameworkCore;
using Pilnik.Models;
using System.Collections.ObjectModel;
using System.Linq;
using System.Windows;
using System.Security.Cryptography;
using System.Text;

namespace Pilnik.Views
{
    
    public partial class CookWindow : Window
    {
        private PilnikContext _context;
        public CookWindow()
        {
            InitializeComponent();
            _context = new PilnikContext();
            LoadOrders();

        }


        private void LoadOrders() 
        {
            var orders = _context.Orders.Include(o => o.User)
            .Include(o => o.OrderProducts)
               .ThenInclude(op => op.Product)
            .Where(o => o.Status == "Принят" || o.Status == "prepare")
            .ToList();

            OrdersGrid.ItemsSource = orders;
        
        }

        private void ButtonPrepare_Click(object sender, RoutedEventArgs e)
        {
            if(OrdersGrid.SelectedItem != null && OrdersGrid.SelectedItem is Order selectedOrder)
            {
                selectedOrder.Status = "prepare";
                _context.SaveChanges();
                LoadOrders();
                OrdersGrid.Items.Refresh(); // Обновление данных в DataGrid
            }
            else
            {
                MessageBox.Show("Выберите заказ для изменения статуса.", "Внимание", MessageBoxButton.OK, MessageBoxImage.Warning);
            }
        }

        private void ButtonReady_Click(object sender, RoutedEventArgs e)
        {
            if (OrdersGrid.SelectedItem != null && OrdersGrid.SelectedItem is Order selectedOrder)
            {
                selectedOrder.Status = "ready";
                _context.SaveChanges();
                LoadOrders();
                OrdersGrid.Items.Refresh(); // Обновление данных в DataGrid
            }
            else
            {
                MessageBox.Show("Выберите заказ для изменения статуса.", "Внимание", MessageBoxButton.OK, MessageBoxImage.Warning);
            }
        }

        private void ButtonExit_Click(object sender, RoutedEventArgs e)
        {
            MainWindow mainWindow = new MainWindow();
            mainWindow.Show();
            this.Close();
        }


    }
}
