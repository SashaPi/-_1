﻿using Pilnik.Models;
using System.Windows;
using System.Windows.Controls;
using Microsoft.EntityFrameworkCore.Metadata.Conventions;



namespace Pilnik.Views
{
    public partial class Adding_ordersWindow : Window
    {
        private readonly PilnikContext _context;
        private Int32 user;

        public Adding_ordersWindow(Int32 currentUser = 1)
        {
            InitializeComponent();
            _context = new PilnikContext();
            this.user = currentUser;

            BackButton.Click += (sender, e) =>
            {
                WaiterWindow waiterWindow = new WaiterWindow();
                waiterWindow.Show();
            };
            var products = _context.Products.ToList();
            ProductsListBox.ItemsSource = products;
        }

        private async void CreateOrderButton_Click(object sender, RoutedEventArgs e)
        {
            try
            {
                var selectedProducts = ProductsListBox.SelectedItems.Cast<Product>().ToList();

                var currentUser = _context.Users.FirstOrDefault(u => u.Id == this.user).Id;

                var place = PlaceTextBox.Text;
                var countPerson = int.Parse(CountPersonTextBox.Text);

                if (string.IsNullOrWhiteSpace(place) || string.IsNullOrWhiteSpace(CountPersonTextBox.Text) || selectedProducts.Count == 0)
                {
                    MessageBox.Show("Заполните все поля.");
                    return;
                }

                var newOrder = new Order
                {
                    UserId = currentUser,
                    Place = place,
                    CountPerson = countPerson,
                    Status = "adopted",
                    Date = DateTime.Now,
                };

                foreach (var product in selectedProducts)
                {
                    newOrder.OrderProducts.Add(new OrderProduct { Product = product });
                }

                _context.Orders.Add(newOrder);
                await _context.SaveChangesAsync();

                MessageBox.Show("Заказ успешно создан", "Успех", MessageBoxButton.OK, MessageBoxImage.Information);
                Close();
            }
            catch (Exception ex)
            {
                MessageBox.Show($"Ошибка при создании заказа: {ex.Message}", "Ошибка", MessageBoxButton.OK, MessageBoxImage.Error);
            }
        }


    }
}
