﻿using Microsoft.EntityFrameworkCore;
using Pilnik.Models;
using Pilnik.Views;
using System.Linq;
using System.Windows;


namespace Pilnik
{
    public partial class MainWindow : Window
    {
        public MainWindow()
        {
            InitializeComponent();
        }

        private void LoginButton_Click(object sender, RoutedEventArgs e)
        {
            // Получаем введенные данные из TextBox и PasswordBox
            var username = UsernameTextBox.Text;
            var password = PasswordBox.Password;

            //Добавляем использование контекстных данных
            using (var context = new PilnikContext())
            {
                // Это строчка ищет пользователя в БД по указанному имени пользователя и паролю
                var user = context.Users.Include(u => u.Role).FirstOrDefault(u => u.Login == username && u.Password == password);

                // Проверка на роль
                if (user != null)
                {
                    switch (user.Role.Name)
                    {
                        case "Administrator":
                            NavigateToWindow(new AdminWindow());
                            break;
                        case "Waiter":
                            NavigateToWindow(new WaiterWindow());
                            break;
                        case "Cook":
                            NavigateToWindow(new CookWindow());
                            break;
                        default:
                            MessageBox.Show("Неизвестная роль пользователя");
                            break;


                    }

                }
                else
                {
                    MessageBox.Show("Неверный логин или пароль");
                }

            }
        }

        private void NavigateToWindow(Window window)
        {
            window.Show();
            Close();
        }

    }
}