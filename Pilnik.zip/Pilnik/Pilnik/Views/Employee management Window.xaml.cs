﻿using Microsoft.EntityFrameworkCore;
using Pilnik.Models;
using System.Collections.ObjectModel;
using System.Linq;
using System.Windows;
using System.Security.Cryptography;
using System.Text;


namespace Pilnik.Views
{
    /// <summary>
    /// Interaction logic for Employee_management_Window.xaml
    /// </summary>
    public partial class Employee_management_Window : Window
    {
        private readonly PilnikContext _context;
        private ObservableCollection<User> _employees;

        public Employee_management_Window()
        {
            InitializeComponent();

            _context = new PilnikContext();
            LoadEmployees();
        }

        private void LoadEmployees()
        {
            _employees = new ObservableCollection<User>(_context.Users.Include(u => u.Role).Where(u => u.Status == "active").ToList());
            EmployeesGrid.ItemsSource = _employees;
        }

        private void FireEmployeeButton_Click(object sender, RoutedEventArgs e)
        {
            if (EmployeesGrid.SelectedItem != null) 
            {
                var selectedEmployee = EmployeesGrid.SelectedItem as User;

                using (var context = new PilnikContext()) 
                {
                    var employeeToUpdate = context.Users.FirstOrDefault(u => u.Id == selectedEmployee.Id);
                    if (employeeToUpdate != null) 
                    {
                        employeeToUpdate.Status = "Inactive";
                        context.SaveChanges();
                        _employees.Remove(selectedEmployee);
                    
                    
                    }
                
                
                
                }

            }
            else 
            {

                MessageBox.Show("Выберите сотрудника для увольнения. ");
            
            
            }
            
        }

        private void AddEmployeeButton_Click(object sender, RoutedEventArgs e)
        {
            Adding_employeesWindow adding_employeesWindow = new Adding_employeesWindow();
            adding_employeesWindow.ShowDialog();
            LoadEmployees();

        }

        private void BackButton_Click(object sender, RoutedEventArgs e)
        {
          
            AdminWindow adminWindow = new AdminWindow();
            this.Close();

            adminWindow.Show();
            

        }

    }
}

