﻿using Pilnik.Models;
using System.Windows;

namespace Pilnik.Views
{
    public partial class AdminWindow : Window
    {
        public AdminWindow()
        {
            InitializeComponent();
        }

        private void ManageButton_Click<T>() where T : Window, new()
        {
            var window = new T();
            window.Show();
            Close();
        }

        private void ManageEmployeesButton_Click(object sender, RoutedEventArgs e)
        {
            ManageButton_Click<Employee_management_Window>();
        }

        private void ManageOrdersButton_Click(object sender, RoutedEventArgs e)
        {
            ManageButton_Click<Viewing_the_list_of_ordersWindow>();
        }

        private void ManageShiftsButton_Click(object sender, RoutedEventArgs e)
        {
            ManageButton_Click<Shift_managementWindow>();
        }

        private void ExitButton_Click(object sender, RoutedEventArgs e)
        {
            ManageButton_Click<MainWindow>();
        }


    }
}

