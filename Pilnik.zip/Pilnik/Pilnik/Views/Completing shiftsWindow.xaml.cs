﻿using Pilnik.Models;
using System.Windows;
using System.Windows.Controls;


namespace Pilnik.Views
{
    public partial class Completing_shiftsWindow : Window
    {

        private readonly PilnikContext _context;

        public Completing_shiftsWindow()
        {
            InitializeComponent();
            _context = new PilnikContext();
            EmployeesListBox.ItemsSource = _context.Users.Where(u => u.Status == "Active").ToList();
        }

        private async void CreateShiftButton_Click(object sender, RoutedEventArgs e)
        {
            var selectedEmployees = EmployeesListBox.SelectedItems.Cast<User>().ToList();
            var startShiftDateTime = StartDatePicker.SelectedDate?.Date + GetTime(StartHourComboBox, StartMinuteComboBox);
            var endShiftDateTime = EndDatePicker.SelectedDate?.Date + GetTime(EndHourComboBox, EndMinuteComboBox);

            string shiftStatus;
            if (DateTime.Now < startShiftDateTime)
            {
                shiftStatus = "Новая смена";
            }
            else if (DateTime.Now >= startShiftDateTime && DateTime.Now <= endShiftDateTime)
            {
                shiftStatus = "active";
            }
            else
            {
                shiftStatus = "inactive";
            }

            var newShift = new Shift
            {
                StartShift = startShiftDateTime ?? DateTime.Today,
                EndShift = endShiftDateTime ?? DateTime.Today,
                StatusShift = shiftStatus
            };

            selectedEmployees.ForEach(emp => newShift.ShiftUsers.Add(new ShiftUser { User = emp }));

            _context.Shifts.Add(newShift);
            await _context.SaveChangesAsync();

            MessageBox.Show("Смена успешно добавлена.", "Успех", MessageBoxButton.OK, MessageBoxImage.Information);
            Close();
        }

        private TimeSpan GetTime(ComboBox hourComboBox, ComboBox minuteComboBox) =>
            TimeSpan.FromHours(int.Parse(((ComboBoxItem)hourComboBox.SelectedItem).Content.ToString()))+
            TimeSpan.FromMinutes(int.Parse(((ComboBoxItem)minuteComboBox.SelectedItem).Content.ToString()));

    }
}

