﻿using System;
using System.Linq;
using System.Windows;
using Pilnik.Models;


namespace Pilnik.Views
{
    public partial class Adding_employeesWindow : Window
    {
        private readonly PilnikContext _context;
        public event EventHandler EmployeeAdded;

        public Adding_employeesWindow()
        {
            InitializeComponent();
            _context = new PilnikContext();
            LoadRoles();
        }

        private void LoadRoles()
        {
            try
            {
                RoleComboBox.ItemsSource = _context.Roles.ToList();
                RoleComboBox.DisplayMemberPath = "Name";

            }
            catch (Exception ex)
            {
                MessageBox.Show("Ошибка при загрузке ролей: " + ex.Message);

            }
        }

        private void AddButton_Click(object sender, RoutedEventArgs e)
        {
            try
            {
                string name = NameTextBox.Text;
                string surname = SurnameTextBox.Text;
                string login = LoginTextBox.Text;
                string password = PasswordTextBox.Text;
                Role selectedRole = RoleComboBox.SelectedItem as Role;

                if (string.IsNullOrWhiteSpace(name) || string.IsNullOrWhiteSpace(surname) ||
                    string.IsNullOrWhiteSpace(password) || selectedRole == null)
                {
                    MessageBox.Show("Заполните все поля. ");
                    return;
                }

                User newUser = new User
                {
                    Name = name,
                    Surname = surname,
                    Login = login.ToLower(),
                    Password = password,
                    RoleId = selectedRole.Id,
                    Status = "Active"

                };

                _context.Users.Add(newUser);
                _context.SaveChanges();

                EmployeeAdded?.Invoke(this, EventArgs.Empty);

                MessageBox.Show("Новый сотрудник успешно добавлен. ");
                this.Close();

            }
            catch (Exception ex)
            {

                MessageBox.Show("Возникла ошибки: " + ex.Message);


            }

        }

    }
}

