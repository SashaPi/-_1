﻿using Pilnik.Models;
using System.Windows;
using System.Windows.Controls;
using Microsoft.EntityFrameworkCore.Metadata.Conventions;
using Microsoft.EntityFrameworkCore.Update;


namespace Pilnik.Views
{
    public partial class Adding_ordersWindow : Window
    {
        private readonly PilnikContext _context;

        public Adding_ordersWindow()
        {
            InitializeComponent();
            _context = new PilnikContext();
            ProductsListBox.ItemsSource = _context.Orders.Where(o => o.Status == "adopted").ToList();
        }

        private async void CreateOrderButton_Click(object sender, RoutedEventArgs e)
        {
            var selectedOrder = ProductsListBox.SelectedItems.Cast<Order>().ToList();
            var startOrderDateTime = StartDatePicker.SelectedDate?.Date;
            


            string orderStatus;
            if (DateTime.Now < startOrderDateTime)
            {
                orderStatus = "Новый заказ";
            }
            else if (DateTime.Now >= startOrderDateTime)
            {
                orderStatus = "adopted";
            }
            else
            {
                orderStatus = "paid for";
            }

            var newOrder = new Order
            {
                Date = startOrderDateTime ?? DateTime.Today,
                Status = orderStatus,
                
            };

            selectedOrder.ForEach(ord => newOrder.OrderProducts.Add(new OrderProduct { Order = ord }));

            _context.Orders.Add(newOrder);
            await _context.SaveChanges();

            MessageBox.Show("Заказ успешно добавлен.", "Успех", MessageBoxButton.OK, MessageBoxImage.Information);
            Close();
        }


    }
}
